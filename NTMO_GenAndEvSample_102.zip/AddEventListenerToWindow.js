//=============================================================================
// AddEventListenerToWindow.js
// ----------------------------------------------------------------------------
// Copyright (c) 2017 Tsumio
// This software is released under the MIT License.
// http://opensource.org/licenses/mit-license.php
// ----------------------------------------------------------------------------
// Version
// 1.0.0 2017/09/23 公開。
// ----------------------------------------------------------------------------
// [Blog]   : http://ntgame.wpblog.jp/
// [Twitter]: https://twitter.com/TsumioNtGame
//=============================================================================

/*:
 * @plugindesc Add events to Window_Selectable class.
 * @author Tsumio
 *
 * 
 * @help Add events to Window_Selectable class.
 * 
 * 
 * ----how to use----
 * This is a plugin that extends Window_Selectable.
 * This plugin itself does not do anything, but it will be able to fire events when Window_Selectable cursor is moved.
 * Register the event in the instance of the class inheriting Window_Selectable.
 * Instances of each window class are usually created in the Scene_XXX class.
 * 
 * example：Execute the onHoge method when the down key of the status window is pressed
 * this._statusWindow.eventListener['onDown'].register(this.onHoge.bind(this));
 * 
 * For detailed code please see OuchCursorMovement.js.
 * 
 * ----specification----
 * The following properties are added to the Window_Selectable class.
 * -> eventListener
 * 
 * Events available for "eventListener"
 * -> onUp    : fire when the up cursor is pressed.
 * -> onDown  : fire when the down cursor is pressed.
 * -> onRight : fire when the right cursor is pressed.
 * -> onLeft  : fire when the left cursor is pressed.
 * 
 * Users typically use the register method of the eventListener property.
 * For the register method's argument, specify the function you want to execute.
 * example：eventListener['onRight'].register(fnc);
 * 
 * ----plugin command----
 * There is none.
 * 
 * 
 * ----change log---
 * 1.0.0 2017/09/23 Release.
 * 
 * ----remarks----
 * This plugin is released as sample code of the following article.
 * http://ntgame.wpblog.jp/2017/09/23/post-930/
 * 
 * I shall not be responsible for any loss, damages and troubles from using this plugin.
 * 
 * --Terms of Use--
 * This plugin is free for both commercial and non-commercial use.
 * You don't have to make sure to credit.
 * Furthermore, you may edit the source code to suit your needs,
 * so long as you don't claim the source code belongs to you.
 * 
 */
/*:ja
 * @plugindesc Window_Selectableクラスにイベントを追加します。
 * @author ツミオ
 *
 * 
 * @help Window_Selectableクラスにイベントを追加します。
 * 
 * 
 * 【使用方法】
 * Window_Selectableを拡張するプラグインです。
 * このプラグイン自体は何もおこないませんが、Window_Selectableのカーソル移動時にイベントを発火できるようになります。
 * Window_Selectableを継承したクラスのインスタンスにおいてイベントを登録してください。
 * 各ウィンドウクラスのインスタンスは、通常Scene_XXXクラスにおいて作成されます。
 * 
 * 例：ステータスウィンドウの下キーが押されたとき、onHogeメソッドを実行
 * this._statusWindow.eventListener['onDown'].register(this.onHoge.bind(this));
 * 
 * 詳しいコードはOuchCursorMovement.jsをご覧ください。
 * 
 * 【仕様】
 * Window_Selectableクラスに以下のプロパティが追加されます。
 * -> eventListener
 * 
 * eventListenerで使用可能なイベント
 * -> onUp    : 上カーソルを押したとき発火
 * -> onDown  : 下カーソルを押したとき発火
 * -> onRight : 右カーソルを押したとき発火
 * -> onLeft  : 左カーソルを押したとき発火
 * 
 * ユーザーは通常、eventListenerプロパティのregisterメソッドを使用します。
 * registerメソッドの引数には実行したい関数を指定します。
 * 例：eventListener['onRight'].register(fnc);
 * 
 * 【プラグインコマンド】
 * このプラグインにプラグインコマンドはありません。
 * 
 * 
 * 【更新履歴】
 * 1.0.0 2017/09/23 公開。
 * 
 * 【備考】
 * 当プラグインは
 * http://ntgame.wpblog.jp/2017/09/23/post-930/
 * の記事の参考コードとして公開されています。
 * また、当プラグインを利用したことによるいかなる損害に対しても、制作者は一切の責任を負わないこととします。
 * 
 * 【利用規約】
 * 作者に無断で改変、再配布が可能で、利用形態（商用、18禁利用等）
 * についても制限はありません。
 * 自由に使用してください。
 * 
 */

(function() {
    'use strict';
    var pluginName = 'AddEventListenerToWindow';

////=============================================================================
//// NTMO
////  Declare NTMO namespace.
////=============================================================================
    var NTMO = NTMO || {};
    NTMO.ELW = function(){
    };

////=============================================================================
//// NTMO.ELW.EventListener
////  This class is event listener for window system.
////=============================================================================
    NTMO.ELW.EventListener = function(){
        this.initialize.apply(this, arguments);
    };

    NTMO.ELW.EventListener.prototype.initialize = function(){
        //Initialize.
        this._callbacks  = [];
    };

    NTMO.ELW.EventListener.prototype.register = function(fnc){
        if(fnc && typeof(fnc) === 'function'){
            this._callbacks.push(fnc);
        }
    };

    NTMO.ELW.EventListener.prototype.fire = function(){
        for(var fnc of this._callbacks){
            fnc();
        }
    };


////=============================================================================
//// Window_Selectable
////  Add a original event listener.
////=============================================================================
    var _Window_Selectable_initialize = Window_Selectable.prototype.initialize;
    Window_Selectable.prototype.initialize = function(x, y, width, height) {
        _Window_Selectable_initialize.call(this,x, y, width, height);
    
        this.createEventListener();
    };

    Window_Selectable.prototype.createEventListener = function(){
        //Map.I used this for the first time.
        this.eventListener = new Map([['onUp',null],['onDown',null],['onLeft',null],['onRight',null]]);
        for(var key of this.eventListener.keys()){
            this.eventListener[key] = new NTMO.ELW.EventListener();
        }

        /*Object type.Of course, This is ok.
        this.eventListener = {onUp:null,onDown:null,onLeft:null,onRight:null};
        for(var key in this.eventListener){
            this.eventListener[key] = new NTMO.ELW.EventListener();
        }*/

        /*Object type.This is also ok,but I don't like this method.
        this.eventListener.onUp    = new NTMO.ELW.EventListener();
        this.eventListener.onDown  = new NTMO.ELW.EventListener();
        this.eventListener.onLeft  = new NTMO.ELW.EventListener();
        this.eventListener.onRight = new NTMO.ELW.EventListener();*/
    };
    
    var _Window_Selectable_cursorDown = Window_Selectable.prototype.cursorDown;
    Window_Selectable.prototype.cursorDown = function(wrap) {
        _Window_Selectable_cursorDown.call(this, wrap);
        this.eventListener.onDown.fire();
    };

    var _Window_Selectable_cursorUp = Window_Selectable.prototype.cursorUp;
    Window_Selectable.prototype.cursorUp = function(wrap) {
        _Window_Selectable_cursorUp.call(this, wrap);
        this.eventListener.onUp.fire();
    };
    
    var _Window_Selectable_cursorRight = Window_Selectable.prototype.cursorRight;
    Window_Selectable.prototype.cursorRight = function(wrap) {
        _Window_Selectable_cursorRight.call(this, wrap);
        this.eventListener.onRight.fire();
    };
    
    var _Window_Selectable_cursorLeft = Window_Selectable.prototype.cursorLeft;
    Window_Selectable.prototype.cursorLeft = function(wrap) {
        _Window_Selectable_cursorLeft.call(this, wrap);
        this.eventListener.onLeft.fire();
    };

})();

