//=============================================================================
// OuchCursorMovement.js
// ----------------------------------------------------------------------------
// Copyright (c) 2017 Tsumio
// This software is released under the MIT License.
// http://opensource.org/licenses/mit-license.php
// ----------------------------------------------------------------------------
// Version
// 1.0.1 2017/09/25 不具合の修正。
// 1.0.0 2017/09/23 公開。
// ----------------------------------------------------------------------------
// [Blog]   : http://ntgame.wpblog.jp/
// [Twitter]: https://twitter.com/TsumioNtGame
//=============================================================================

/*:
 * @plugindesc This plugin remodel the status scene.
 * @author Tsumio
 *
 * 
 * @help This plugin remodel the status scene.
 * 
 * ----feature----
 * -> When press the up and down keys, generate events.
 * -> The screen shakes.
 * 
 * ----how to use----
 * You can use it by only introducing.
 * 
 * 
 * ----plugin command----
 * There is none.
 * 
 * 
 * ----change log---
 * 1.0.1 2017/09/25 Bug fix.
 * 1.0.0 2017/09/23 Release.
 * 
 * ----remarks----
 * This plugin is released as sample code of the following article.
 * http://ntgame.wpblog.jp/2017/09/23/post-930/
 * 
 * I shall not be responsible for any loss, damages and troubles from using this plugin.
 * 
 * --Terms of Use--
 * This plugin is free for both commercial and non-commercial use.
 * You don't have to make sure to credit.
 * Furthermore, you may edit the source code to suit your needs,
 * so long as you don't claim the source code belongs to you.
 * 
 */
/*:ja
 * @plugindesc ステータス画面を改造するプラグインです。
 * @author ツミオ
 *
 * 
 * @help ステータス画面を改造するプラグインです。
 * 
 * 【特徴】
 * ・上下キーを押すとイベントが発生します。
 * ・画面が揺れます。
 * 
 * 【使用方法】
 * プラグインを導入するだけで使用できます。
 * 
 * 【プラグインコマンド】
 * このプラグインにプラグインコマンドはありません。
 * 
 * 
 * 【更新履歴】
 * 1.0.1 2017/09/25 不具合の修正。
 * 1.0.0 2017/09/23 公開。
 * 
 * 【備考】
 * 当プラグインは
 * http://ntgame.wpblog.jp/2017/09/23/post-930/
 * の記事の参考コードとして公開されています。
 * また、当プラグインを利用したことによるいかなる損害に対しても、制作者は一切の責任を負わないこととします。
 * 
 * 【利用規約】
 * 作者に無断で改変、再配布が可能で、利用形態（商用、18禁利用等）
 * についても制限はありません。
 * 自由に使用してください。
 * 
 */

(function() {
    'use strict';
    var pluginName = 'OuchCursorMovement';

////=============================================================================
//// NTMO
////  Declare NTMO namespace.
////=============================================================================
    var NTMO = NTMO || {};
    NTMO.OCM = function(){
    };

////=============================================================================
//// Scene_Menu
////  This is event listener sample.
////=============================================================================
    var _Scene_Menu_createStatusWindow = Scene_Menu.prototype.createStatusWindow;
    Scene_Menu.prototype.createStatusWindow = function() {
        _Scene_Menu_createStatusWindow.call(this);
        this._statusWindow.eventListener['onDown'].register(this.onHoge.bind(this));
        this._statusWindow.eventListener['onDown'].register(this.onHoge2.bind(this));
        this._statusWindow.eventListener['onUp'].register(this.onOuch.bind(this));
        this._statusWindow.eventListener['onUp'].register(this.onHoge2.bind(this));

        this.messageHoge  = 'ほげえええええ';
        this._genHpDamage = this.genOuch();
    };

    Scene_MenuBase.prototype.create = function() {
        Scene_Base.prototype.create.call(this);
        this.createBackground();
        if(SceneManager._scene.constructor === Scene_Menu){//Added.
            this.createSpriteset();
        }
        this.updateActor();
        this.createWindowLayer();
    };

    Scene_Menu.prototype.createSpriteset = function() {
        this._spriteset = new Spriteset_Battle();
        this.addChild(this._spriteset);
    };

    var _Scene_Menu_update = Scene_Menu.prototype.update;
    Scene_Menu.prototype.update = function() {
        _Scene_Menu_update.call(this);

        $gameScreen.update();
        $gameParty.requestMotionRefresh();
    };

    Scene_Menu.prototype.onHoge = function() {
        console.log(this.messageHoge);
    };

    Scene_Menu.prototype.onHoge2 = function() {
        console.log('吾輩がほげ2である。');
    };

    Scene_Menu.prototype.onOuch = function() {
        this._genHpDamage.next();
    };

    Scene_Menu.prototype.loseHitPointGradually = function(damage) {
        var party = $gameParty.members();
        party.forEach(function(member){
            member.gainHp(-damage);
        }, this);
        this._statusWindow.refresh();
    };

    Scene_Menu.prototype.genOuch = function*() {
        while(true){
            this.loseHitPointGradually(200);
            $gameScreen.startShake(2,2,60);
            yield;
            this.loseHitPointGradually(400);
            $gameScreen.startShake(4,4,120);
            yield;
            this.loseHitPointGradually(800);
            $gameScreen.startShake(6,6,180);
            yield;
            this.loseHitPointGradually(1600);
            $gameScreen.startShake(8,8,240);
            yield;
            this.loseHitPointGradually(3200);
            $gameScreen.startShake(10,10,300);
            yield;
        }
    };

})();
